set pagination off
set print pretty on

break parse.c:2852

start
continue

#p *stmt->for_init->stmts
#p *((Node*) vec_get( stmt->for_init->stmts, 0 ))
#p *(((Node*) vec_get( stmt->for_init->stmts, 0 ))->declvar)
#p *(((Node*) vec_get( stmt->for_init->stmts, 0 ))->declvar)->label
