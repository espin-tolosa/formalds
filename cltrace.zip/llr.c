#include <stdio.h>
#include <string.h>

#include "8cc.h"

static const char * cc8_emmit__llr( void * tbd );
static void cc8_emmit__pout_llr( void );

static const char * cc8_emmit__fundec__type( Node *node );
static const char * cc8_emmit__fundec__args( Node *node );
static const char * cc8_emmit__fundec__rettype( Node *node );

int strnreplace
(
    char *buf,
    size_t buf_size,
    const char *pattern,
    const char *replacement
);

int str_count_occurrences
(
    const char *buffer,
    const char *pattern
);

void cc8_emmit_llrs( Vector * toplevels )
{
//    for (int i = 0; i < vec_len(toplevels); i++)
//    {
//        Node *v = vec_get(toplevels, i);
//
//        printf("%s", node2s(v));
//    }

//    Node *v = vec_get(toplevels, 0);

//    printf("Number of top levels: %d\n", vec_len(toplevels));

    const int toplevels_len = vec_len(toplevels);

    for ( int i = 0; i < toplevels_len; i++ )
    {
        Node *v = vec_get(toplevels, i);

        if( v->kind == AST_FUNC )
        {
            cc8_emmit__pout_llr();

            printf(" The CSU %s shall implement function `%s` returning `%s`%s\n",
                v->sourceLoc->file,
                v->fname,
                cc8_emmit__fundec__rettype(v),
                cc8_emmit__fundec__args(v) );

            {
                for (int i = 0; i < vec_len(v->body->stmts); i++)
                {

                    Node * stmt = vec_get(v->body->stmts, i);

                    if( stmt->kind == AST_DECL )
                    {
                        cc8_emmit__pout_llr();
                        char tmp_buf[ 1024 ];
                        strcpy( tmp_buf, node2s( stmt ) );
                        strnreplace( tmp_buf, 1024, "${func}", "`${func}`" );
                        strnreplace( tmp_buf, 1024, "${func}", v->fname );
                        printf( tmp_buf );
                    }

                    else if( stmt->kind == AST_IF )
                    {
                        cc8_emmit__pout_llr();
                        char tmp_buf[ 1024 ];
                        strcpy( tmp_buf, node2s( stmt ) );
                        strnreplace( tmp_buf, 1024, "${func}", "`${func}`" );
                        strnreplace( tmp_buf, 1024, "${func}", v->fname );

                        const int count_then = str_count_occurrences( tmp_buf, "${THEN}" );

                        for( int i = 0; i < count_then; ++i )
                        {
                            if(i!=(count_then-1))
                            {
                                strnreplace( tmp_buf, 1024, "${THEN}\n", "AND\n" );
                            }

                            else
                            {
                                strnreplace( tmp_buf, 1024, "${THEN}", "THEN" );
                            }
                        }

                        const int count_valof = str_count_occurrences( tmp_buf, "${the value of}" );

                        for( int i = 0; i < count_valof; ++i )
                        {
                            strnreplace( tmp_buf, 1024, "${the value of}", "" );
                        }


                        printf( tmp_buf );
                    }

                    else if( stmt->kind == AST_RETURN )
                    {
                        cc8_emmit__pout_llr();

                        char tmp_buf[ 1024 ];
                        strcpy( tmp_buf, node2s( stmt ) );
                        strnreplace( tmp_buf, 1024, "${func}", "`${func}`" );
                        strnreplace( tmp_buf, 1024, "${func}", v->fname );
                        strnreplace( tmp_buf, 1024, "${the value of}", "" );
                        printf( "%s\n\n", tmp_buf );
                    }

                    else
                    {
                        cc8_emmit__pout_llr();

                        if( stmt->kind == AST_COMPOUND_FOR )
                        {
                            printf("INIT: %s\n", node2s( stmt->for_init ) );
                            printf("STEP: %s\n", node2s( stmt->for_step ) );
                            printf("COND: %s\n", node2s( stmt->for_cond ) );
                            printf("BODY: %s\n", node2s( stmt->for_body ) );
                        }

//                        printf(node2s(stmt) );
                    }

//                                buf_printf(b, "`%s`", node->varname);
//        if (node->lvarinit) {
//            buf_printf(b, "(");
//            a2s_declinit(b, node->lvarinit);
//            buf_printf(b, ")");
//        }

                }
            }
        }

        else
        {
            cc8_emmit__pout_llr();

            printf(" TODO: complete the rest of top levels types\n\n" );
        }
    }

}

/*
 * General Identifiers
 */

static const char * cc8_emmit__llr( void * tbd )
{
    static char llr[ 256 ];
    memset( llr, 0, sizeof(llr) );

    snprintf( llr, 255, "[LLR-ID-%03d]", *((int*) tbd) );

    return ( llr );
}
static void cc8_emmit__pout_llr( void )
{
    static int id = 1;
    printf("\n------------------------------------------------------------------------------------------------------------");
    printf(" %s\n", cc8_emmit__llr( &id ) );

    id++;
}


/*
 * Functions Declarations
 */

static const char * cc8_emmit__fundec__type( Node *node )
{
    Buffer *b = make_buffer();

    buf_printf(b, "%s", ty2s(node->ty));

    return buf_body(b);
}

static const char * cc8_emmit__fundec__args( Node *node )
{
    Buffer *b = make_buffer();

    const int params_len = vec_len(node->params);

    if( params_len == 0 )
    {
        buf_printf(b, ", whithout arguments.\n\n");
    }

    else
    {
        buf_printf(b, ", whith arguments:\n\n");

        int max_len = 0;
        for (int i = 0; i < vec_len(node->params); i++)
        {
            Node *param = vec_get(node->params, i);
            const int len = strlen( node2s(param) );
            max_len = max_len < len ? len : max_len;
        }

        for (int i = 0; i < vec_len(node->params); i++)
        {
            Node *param = vec_get(node->params, i);
            buf_printf(b, "    - %-*s of type: %s\n", max_len, node2s(param), ty2s(param->ty));
        }
    }


    return buf_body(b);
}

static const char * cc8_emmit__fundec__rettype( Node *node )
{
    Buffer *b = make_buffer();

    buf_printf(b, "%s", ty2s(node->ty->rettype));

    return buf_body(b);
}

/*
 * If statements
 */

static const char * cc8_emmit__if__chain( Node *node )
{

}

#include <string.h>
#include <stdio.h>

int strnreplace
(
    char *buf,
    size_t buf_size,
    const char *pattern,
    const char *replacement
)
{
    char *pos;
    size_t buf_len;
    size_t pat_len;
    size_t rep_len;
    size_t new_len;
    char tmp[buf_size];

    if ( buf == NULL || pattern == NULL || replacement == NULL )
    {
        return -1;
    }

    pos = strstr( buf, pattern );
    if ( pos == NULL )
    {
        return 0;
    }

    buf_len = strlen( buf );
    pat_len = strlen( pattern );
    rep_len = strlen( replacement );

    new_len = buf_len - pat_len + rep_len;
    if ( new_len + 1 > buf_size )
    {
        return -1;
    }

    memcpy( tmp, buf, (size_t)( pos - buf ) );
    memcpy( tmp + ( pos - buf ), replacement, rep_len );
    memcpy(
        tmp + ( pos - buf ) + rep_len,
        pos + pat_len,
        buf_len - ( pos - buf ) - pat_len + 1
    );

    memcpy( buf, tmp, new_len + 1 );

    return 1;
}

int str_count_occurrences
(
    const char *buffer,
    const char *pattern
)
{
    const char *p;
    size_t pattern_len;
    int count;

    if ( buffer == NULL || pattern == NULL )
        return 0;

    pattern_len = strlen( pattern );
    if ( pattern_len == 0 )
        return 0;

    count = 0;
    p = buffer;

    for (;;)
    {
        p = strstr( p, pattern );
        if ( p == NULL )
            break;

        count++;
        p += pattern_len;
    }

    return count;
}
