# Loops

```c
for( clause-1 ; expression-2 ; expression-3 ) statement
```

`clause-1`, and `expression-3` can be omitted without effect.