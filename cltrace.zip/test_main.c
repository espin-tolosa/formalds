int my_sum( int, int );

extern int g_a[ 10 ];

int example( int a, int b )
{
    int min = 0;

    if( a < b )
        min = a;    
    else
        min = b; 

    return ( min / 2 );
}

#if 0

int my_sum( int a, int b, char ** argv[] )
{
    int * ret = &a - (int) "Hello";

    int z = a+++b+++0;

    if( a || b )
    {
        if( a > 6 )
        {
            *ret = 100;
        }
        else
        {
            *ret = 0;
        }
    }

    return ( *ret );
}

#define INT_MAX (+10)
#define INT_MIN (-10)
#define DOMAIN_ERROR_INTEGER_OVERFLOW (1)

extern sum(int,int);

extern int math_safe__isum( int a, int b, int * err )
{
    int ret = sum(10,12);

    if( a >= 0 )
    {
        if( b > ( INT_MAX - a ) )
        {
            *err = DOMAIN_ERROR_INTEGER_OVERFLOW;
        }

        else
        {
            ret = a + b;
            *err = 0;
        }
    }

    else
    {
        if( b < ( INT_MIN - a ) )
        {
            *err = DOMAIN_ERROR_INTEGER_OVERFLOW;
        }

        else
        {
            ret = a + b;
            *err = 0;
        }
    }

    return ( ret );
}

int msum_int
(
    int a,
    int b,
    int * const error
)
{
    int result;

    const _Bool a_plus_b_overflows      = ( a > 0 ) && ( b > (INT_MAX - a));
    const _Bool a_plus_b_underflows     = ( a < 0 ) && ( b < (INT_MIN - a));

    if ( a_plus_b_overflows || a_plus_b_underflows )
    {
        *error = DOMAIN_ERROR_INTEGER_OVERFLOW;
        return 0;
    }

    *error = 0;

    return ( a + b );
}
#endif

#if 0 /* OK: function declaration, variable initialization, if condition */
int main( int argc, const char * argv )
{
    int ok = 0;

    const float zz = 125.0;

    if( argc != 0 )
    {
        if( argv != NULL )
        {
            if( strcmp( argv[ 0 ], "keyword" ) != 0 ) // TODO: re-group nodes to the higher level: WHEN argv at 0 is not equal "keyword"
            {
                int my_var = sum(1,2);
            }
        }
    }
}
#endif

#if 0
static int my_top;

extern float other_top;

static int arr_top[ 19 ];

int strncpy(const char*, const char*);
typedef struct
{
    const char * name;
    int age;
    int length;
} user;

static int alloc_array[ 10000 ] = { 0 };

struct top_level_struct;

extern int zz( void );

int add(int length, int b, const char * name, float * r)
{
    if( zz() > 0 )
    {
        if( zz() == 1 )
        {
            return 10;
        }

        else
        {
            return 100;
        }
    }

    return ( length + b );
}

int sum( const char * a, int b, int x, const char * zzz_my_, user * u )
{
    const int a = 0;
    int c = 0;
    int e = 0;
    int d = 0;

    const my_var = sum(1,2);

    int * array;

    int i, j, k;
    array[ i ] = 5;

    user my_user;

    my_user.age = 10;

    (void) strncpy( my_user.name, "samuel" );

    if( !(a <= c) )
    {
        d = 1;
    }

    else
    {
        d = 4;
    }

    /* >> LLT-ID-001 */
    return ;
    /* << LLT-ID-001 */
}

int test(void)
{
    if(sum(1,2)!=0)
    {
        int a = 0;
    }

    const int z = 1;
    z = 2;


}
#endif
