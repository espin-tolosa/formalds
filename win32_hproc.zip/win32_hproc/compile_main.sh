#gcc $( pkg-config --cflags gtk4 ) -o main_gtk_process main_gtk_process.c $( pkg-config --libs gtk4 )

x86_64-w64-mingw32-gcc window_win32_process.c main_win32_process.c -o main_win32_process.exe -Wall -save-temps

x86_64-w64-mingw32-gcc window_win32_process.c cheat_core.c cheat_win32.c -o cheat_win32.exe -Wall
