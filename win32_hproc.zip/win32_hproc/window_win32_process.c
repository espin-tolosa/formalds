#include "cheat_core.h"

#define ID_BUTTON 1

const char g_path[] = "Content of the button";

const char CLASS_NAME[] = "SimpleWindowClass";

extern LRESULT CALLBACK WndProc (HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch (msg)
    {
        case WM_COMMAND:
            if (LOWORD (wParam) == ID_BUTTON)
            {
                printf ( "%s\n", g_path );
                fflush (stdout);
            }
            break;

        case WM_DESTROY:
            PostQuitMessage (0);
            break;
    }
    return DefWindowProc (hwnd, msg, wParam, lParam);
}

HWND on_user_create( HINSTANCE hInstance )
{
        HWND hwnd = CreateWindowEx (
        0,
        CLASS_NAME,
        "Win32 Process",
        WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, CW_USEDEFAULT, 300, 200,
        NULL,
        NULL,
        hInstance,
        NULL
    );

    if (!hwnd) return 0;

    CreateWindow (
        "BUTTON",
        "Click Me",
        WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON,
        50, 50, 100, 30,
        hwnd,
        (HMENU)ID_BUTTON,
        hInstance,
        NULL
    );

    return ( hwnd );
}