#include "cheat_core.h"

extern const char g_path[];

int main( void )
{
    HWND hwnd = FindWindow( 0, "Win32 Process" );

    DWORD pid;

    (void) GetWindowThreadProcessId( hwnd, &pid );

    HANDLE ps = OpenProcess( PROCESS_ALL_ACCESS, true, pid );

    if( !ps )
    {
        fprintf(stderr, "[ERROR] process not found\n");
        fflush(stderr);
        exit(1);
    }

    /*
     * Cheat on the string
     */

    uintptr_t main_base             = cheat_core__get_process_base_ptr( pid, L"main_win32_process.exe" );
    uintptr_t g_path_rva            = (uintptr_t)g_path - (uintptr_t)GetModuleHandleA(NULL);
    LPVOID  remote_g_path_addr      = (LPVOID) ( main_base + g_path_rva );
    char    new_g_path_content[]    = "Cheated Window!";

    if( WriteProcessMemory( ps, remote_g_path_addr, &new_g_path_content, sizeof(new_g_path_content), NULL) == 0 )
    {
        fprintf(stderr, "[ERROR] failed to write on g_path_address\n");
        fflush(stderr);
        exit(1);
    }

    /*
     * Call the button with the cheated string
     */

    HWND hwndButton = FindWindowEx(hwnd, NULL, "BUTTON", "Click Me");

    if ( !hwndButton )
    {
        fprintf(stderr, "[ERROR] button not found\n");
        fflush(stderr);
        exit(1);
    }

   SendMessage(hwndButton, BM_CLICK, 0, 0);

   CloseHandle(ps);

    return ( 0 );
}

