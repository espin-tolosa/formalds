#include <windows.h>
#include <stdio.h>

extern LRESULT CALLBACK WndProc (HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

HWND on_user_create( HINSTANCE hInstance );

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
    const char CLASS_NAME[] = "SimpleWindowClass";
    WNDCLASS wc = {0};

    wc.lpfnWndProc   = WndProc;
    wc.hInstance     = hInstance;
    wc.lpszClassName = CLASS_NAME;
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);

    RegisterClass (&wc);

    HWND hwnd = on_user_create( hInstance );

    ShowWindow (hwnd, nCmdShow);
    UpdateWindow (hwnd);

    // Message loop
    MSG msg;
    while (GetMessage (&msg, NULL, 0, 0) > 0)
    {
        TranslateMessage (&msg);
        DispatchMessage (&msg);
    }

    return 0;
}
