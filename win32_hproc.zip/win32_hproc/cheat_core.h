#ifndef INCLUDE_HEADER_CHEAT_CORE_H
#define INCLUDE_HEADER_CHEAT_CORE_H

#include <windows.h>
#include <tlhelp32.h>

#include <tchar.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdbool.h>

extern uintptr_t cheat_core__get_process_base_ptr(DWORD processID, const wchar_t* nombre_del_modulo);

#endif
