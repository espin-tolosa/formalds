#include <malloc.h>
#include "kv_vector.h"

#define MAX_CAPACITY (1u << 30)
#define GROWTH_RATIO 2

vector_t kv_new( unsigned int size )
{
    vector_t ret = { 0 };

    unsigned int init_sz = size < MAX_CAPACITY ? size : MAX_CAPACITY;

    ret.elems = calloc(init_sz, sizeof(vector_t));

    if(ret.elems != NULL)
    {
        ret.len = 0;
        ret.size = init_sz;
    }

    return ( ret );
}

unsigned int kv_push(vector_t *this, const void *key, const void *val)
{
    if (this->len == this->size && this->size < MAX_CAPACITY)
    {
        if( this->size == 0 )
        {
            this->size++;
        }

        unsigned int new_size = (this->size * GROWTH_RATIO > MAX_CAPACITY) ? MAX_CAPACITY : this->size * GROWTH_RATIO;

        /* Reallocate both keys and vals in-place */
        void *p1 = NULL;

        if( this->elems != NULL )
        {
            p1 = realloc(this->elems, new_size * sizeof(kv_t));
        }

        else
        {
            p1 = malloc( sizeof(kv_t) );
        }

        if (p1 != NULL)
        {
            this->elems = p1;
            this->size = new_size;
        }
    }

    /* Add the key-value pair now that space has been ensured */
    if( this->len < this->size )
    {
        this->elems[this->len].k = key;
        this->elems[this->len].v = val;
        this->len++;
    }

    return this->len;
}

const void * kv_find( vector_t *this, const void *key )
{
    for(unsigned int i = 0; i < this->len; ++i)
        if( this->elems[i].k == key )
            return ( this->elems[i].v );

    return ( NULL );
}
