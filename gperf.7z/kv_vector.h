#ifndef KV_VECTOR
#define KV_VECTOR

typedef struct kv
{
    const void * k;
    const void * v;
} kv_t;

typedef struct vector
{
    kv_t * elems;
    unsigned int len;
    unsigned int size;
} vector_t;

vector_t        kv_new  ( unsigned size                                    );
const char *    kv_find ( vector_t *this, const void *key                  );
unsigned int    kv_push ( vector_t *this, const void *key, const void *val );

#endif
