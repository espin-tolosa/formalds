#include <time.h>
#include <stdio.h>

#include "kv_vector.h"

extern vector_t g_map;

extern void * fun_address[ 100 ];
extern const char * fun_name[ 100 ];

struct timespec res;
long long int nano1,nano2;

#define NANOS 1.e-0
#define MICROS 1.e-3
#define MILLIS 1.e-6
#define SECONDS 1.e-9

#define PLAY_TIMER clock_gettime(CLOCK_REALTIME,&res); nano1 = res.tv_nsec;
#define RESUME_TIMER clock_gettime(CLOCK_REALTIME,&res); nano2 = res.tv_nsec;
#define GET_LAST_TIME(type, scale) (type) ( (nano2-nano1)*scale )

void __cyg_profile_func_enter (void *this_fn, void *call_site)
{
    PLAY_TIMER;
    printf("Play Timer: %lu\n", nano1);
}

void __cyg_profile_func_exit (void *this_fn, void *call_site)
{
    RESUME_TIMER;
    printf("Resume Timer: %lu\n", nano2);

    const char * found_fname = kv_find( &g_map, this_fn );

    printf( "%30s time: %llu(us)\n", found_fname?found_fname:"not-found", GET_LAST_TIME(long long, MICROS));

//    printf( "[%s] %f(ns)\n", found_fname, GET_LAST_TIME );
}