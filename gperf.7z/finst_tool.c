#include <time.h>
#include <stdio.h>

#include "kv_vector.h"

extern vector_t g_map;

extern void * fun_address[ 100 ];
extern const char * fun_name[ 100 ];

struct timespec res;
unsigned long long int nano1,nano2;

extern unsigned long long g_timer;

#define NANOS 1.e-0
#define MICROS 1.e-3
#define MILLIS 1.e-6
#define SECONDS 1.e-9

#define PLAY_TIMER clock_gettime(CLOCK_REALTIME,&res); nano1 = res.tv_nsec;
#define RESUME_TIMER clock_gettime(CLOCK_REALTIME,&res); nano2 = res.tv_nsec;
#define GET_LAST_TIME(type, scale) (type) ( (nano2>nano1?nano2-nano1:0)*scale )

#if 0

fun0
    .
    .
    .
    call_site1 -> fu1                                    -> timer_fun1
                     .
                     .
                     .
                     call_site2 -> fu2                    -> stop timer_fun1 , play timer_fun2
                                      .
                                      .
                                      .
                     call_site2 <- fu2                    -> stop timer_fun2 , play timer fun1
                     .
                     .
                     .
                     .
     call_site1 <- fu1
     .
     .
     .
ret

#endif

void __cyg_profile_func_enter (void *this_fn, void *call_site)
{
    const void * v = kv_find( &g_map, this_fn );

    if(v != NULL)
    {
        PLAY_TIMER;
    }
}

void __cyg_profile_func_exit (void *this_fn, void *call_site)
{
    const void * v = kv_find( &g_map, this_fn );

    if(v != NULL)
    {
        RESUME_TIMER;
        printf( "%llu\n", GET_LAST_TIME(long long, MICROS) );
        g_timer += GET_LAST_TIME(long double, NANOS);
    }
}

#if 0
void __cyg_profile_func_enter (void *this_fn, void *call_site)
{
    printf("Play Timer: %lld\n", nano1);
}

void __cyg_profile_func_exit (void *this_fn, void *call_site)
{
    RESUME_TIMER;
    printf("Resume Timer: %lld\n", nano2);

    const char * found_fname = kv_find( &g_map, this_fn );

    printf( "%30s time: %llu(us)\n", found_fname?found_fname:"not-found", GET_LAST_TIME(long long, MICROS));

//    printf( "[%s] %f(ns)\n", found_fname, GET_LAST_TIME );
}
#endif