#include <math.h>
#include <unistd.h>
#include <stdio.h>

#include "../spt_math/src/math_primitives.c"
#include "../spt_math/src/math_sqrt.c"
#include "../spt_math/src/math_exp.c"
#include "../spt_math/src/math_log.c"
#include "../spt_math/src/math_sin.c"
#include "../spt_math/src/math_asin.c"
#include "../spt_math/src/math_pow.c"

#include "kv_vector.h"

#define NUM_FUNCTIONS 3

vector_t g_map;

double function_times[NUM_FUNCTIONS] = {0}; // Array to store time for each function
int active_function = -1;                  // ID of the currently active function
struct timespec start_time;                // Tracks when the current function started

// Example functions
void test_perf_math_sqrt()
{
    volatile double y;
    volatile int x;
    y = math_sqrt( (double)x++ );
    y = math_sqrt( (double)x++ );
    y = math_sqrt( (double)x++ );
    y = math_sqrt( (double)x++ );
    y = math_sqrt( (double)x++ );
    y = math_sqrt( (double)x++ );
    y = math_sqrt( (double)x++ );
    y = math_sqrt( (double)x++ );
    y = math_sqrt( (double)x++ );

    y = math_exp( (double)x++ );
    y = math_exp( (double)x++ );
    y = math_exp( (double)x++ );
    y = math_exp( (double)x++ );
    y = math_exp( (double)x++ );
    y = math_exp( (double)x++ );
    y = math_exp( (double)x++ );
    y = math_exp( (double)x++ );
    y = math_exp( (double)x++ );

    y = math_log( (double)x++ );
    y = math_log( (double)x++ );
    y = math_log( (double)x++ );
    y = math_log( (double)x++ );
    y = math_log( (double)x++ );
    y = math_log( (double)x++ );
    y = math_log( (double)x++ );
    y = math_log( (double)x++ );
    y = math_log( (double)x++ );


    y = math_sin( (double)x++ );
    y = math_sin( (double)x++ );
    y = math_sin( (double)x++ );
    y = math_sin( (double)x++ );
    y = math_sin( (double)x++ );
    y = math_sin( (double)x++ );
    y = math_sin( (double)x++ );
    y = math_sin( (double)x++ );
    y = math_sin( (double)x++ );

    y = math_cos( (double)x++ );
    y = math_cos( (double)x++ );
    y = math_cos( (double)x++ );
    y = math_cos( (double)x++ );
    y = math_cos( (double)x++ );
    y = math_cos( (double)x++ );
    y = math_cos( (double)x++ );
    y = math_cos( (double)x++ );
    y = math_cos( (double)x++ );

    y = math_asin( (double)x++ );
    y = math_asin( (double)x++ );
    y = math_asin( (double)x++ );
    y = math_asin( (double)x++ );
    y = math_asin( (double)x++ );
    y = math_asin( (double)x++ );
    y = math_asin( (double)x++ );
    y = math_asin( (double)x++ );
    y = math_asin( (double)x++ );

    y = math_pow( (double)x++, 5.0 );
    y = math_pow( (double)x++, 5.0 );
    y = math_pow( (double)x++, 5.0 );
    y = math_pow( (double)x++, 5.0 );
    y = math_pow( (double)x++, 5.0 );
    y = math_pow( (double)x++, 5.0 );
    y = math_pow( (double)x++, 5.0 );
    y = math_pow( (double)x++, 5.0 );
    y = math_pow( (double)x++, 5.0 );
}

int main()
{
    printf("main\n");

    g_map = kv_new( 0 );

    kv_push( &g_map, math_sqrt,             "math_sqrt\n====================\n"             );
    kv_push( &g_map, math_sqrt_imp,         "math_sqrt_imp"         );

    kv_push( &g_map, math_exp,              "math_exp\n====================\n"              );
    kv_push( &g_map, math_exp_imp,          "math_exp_imp"          );

    kv_push( &g_map, math_log,              "math_log\n====================\n"              );
    kv_push( &g_map, math_log_imp_cody,     "math_log_imp_cody"     );

    kv_push( &g_map, math_sin,              "math_sin\n====================\n"              );
    kv_push( &g_map, math_cos,              "math_cos\n====================\n"              );
    kv_push( &g_map, math_sin_impl,         "math_sin_impl"         );

    kv_push( &g_map, math_asin,             "math_asin\n====================\n"             );
    kv_push( &g_map, math_asin_impl,        "math_asin_impl"        );

    kv_push( &g_map, math_pow,              "math_pow\n====================\n"              );
    kv_push( &g_map, math_pow_safe_exp,     "math_pow_safe_exp"     );
    kv_push( &g_map, math_pow_iabs    ,     "math_pow_iabs"         );
    kv_push( &g_map, math_pow_impl    ,     "math_pow_impl"         );
    kv_push( &g_map, math_pow_i16     ,     "math_pow_i16"          );
    kv_push( &g_map, math_pow_ydexp   ,     "math_pow_ydexp"        );
    kv_push( &g_map, math_pow_clamp   ,     "math_pow_clamp"        );

    kv_push( &g_map, math_type,             "math_type"             );
    kv_push( &g_map, math_cwnormalize,      "math_cwnormalize"      );
    kv_push( &g_map, math_cwsetexp,         "math_cwsetexp"         );
    kv_push( &g_map, math_horner,           "math_horner"           );
    kv_push( &g_map, math_intrnd,           "math_intrnd"           );
    kv_push( &g_map, math_intrnd_impl,      "math_intrnd_impl"      );
    kv_push( &g_map, math_biased_exponent,  "math_biased_exponent"  );
    kv_push( &g_map, math_significand,      "math_significand"      );
    kv_push( &g_map, math_scale,            "math_scale"            );
    kv_push( &g_map, math_norm,             "math_norm"             );

    test_perf_math_sqrt();

//    printf("num fun: %d\n", NUM_FUNCTIONS);
//    for (int i = 0; i < NUM_FUNCTIONS; i++)
//    {
//        printf("Time spent in function %d: %.6f seconds\n", i, function_times[i]);
//    }

    return 0;
}
