/* dummy_test_file.c */

#include <stdio.h>
#include <stdlib.h>

typedef double f64_t;
typedef float  f32_t;
typedef int    i32_t;

/* -------------------------------------------------- */
/* Noise: macros and unrelated declarations           */
/* -------------------------------------------------- */

#define SQR(x) ((x) * (x))
#define UNUSED(x) (void)(x)

struct vec3
{
    f64_t x;
    f64_t y;
    f64_t z;
};

union number
{
    f64_t d;
    i32_t i;
};

enum mode
{
    MODE_A,
    MODE_B
};

/* -------------------------------------------------- */
/* Noise: near-miss function signatures                */
/* -------------------------------------------------- */

f64_t almost_match_1( f64_t x, f64_t y )
{
    return x + y;
}

f64_t almost_match_2( f64_t x, f64_t y, f32_t z )
{
    return x + y + z;
}

f32_t almost_match_3( f64_t x, f64_t y, f64_t z )
{
    return (f32_t)( x + y + z );
}

static f64_t almost_match_4( f64_t x, f64_t y, f64_t z, f64_t w )
{
    return x + y + z + w;
}

inline f64_t expect_match_5( f64_t x, f64_t y, const f64_t z )
{
    return x + y + z;
}

/* -------------------------------------------------- */
/* EXPECTED MATCHES                                   */
/* (double, double, double) -> double                 */
/* -------------------------------------------------- */

f64_t expect_add( f64_t x, f64_t y, f64_t z )
{
    return x + y + z;
}

static f64_t expect_mul( f64_t a, f64_t b, f64_t c )
{
    return a * b * c;
}

inline f64_t expect_fma_like( f64_t x, f64_t y, f64_t z )
{
    return x * y + z;
}

f64_t expect_constant( f64_t x, f64_t y, f64_t z )
{
    UNUSED( x );
    UNUSED( y );
    UNUSED( z );
    return 42.0;
}

/* -------------------------------------------------- */
/* Noise: function pointers                           */
/* -------------------------------------------------- */

typedef f64_t (*fp3_t)( f64_t, f64_t, f64_t );

f64_t expect_fp_target( f64_t x, f64_t y, f64_t z )
{
    return x - y - z;
}

fp3_t get_fp( void )
{
    return expect_fp_target;
}

/* -------------------------------------------------- */
/* Noise: similar but wrong via typedef trickery      */
/* -------------------------------------------------- */

typedef f64_t (*fp_wrong_t)( f64_t, f64_t, int );

f64_t wrong_sig_typedef( f64_t x, f64_t y, int z )
{
    return x + y + z;
}

/* -------------------------------------------------- */
/* Noise: struct / array parameters                   */
/* -------------------------------------------------- */

f64_t struct_param( struct vec3 v )
{
    return v.x + v.y + v.z;
}

f64_t array_param( f64_t v[3] )
{
    return v[0] + v[1] + v[2];
}

/* -------------------------------------------------- */
/* EXPECTED MATCHES mixed with other code              */
/* -------------------------------------------------- */

f64_t expect_nested_use( f64_t x, f64_t y, f64_t z )
{
    return expect_add( x, y, z );
}

void unrelated_procedure( void )
{
    printf( "hello\n" );
}

f64_t expect_with_locals( f64_t x, f64_t y, f64_t z )
{
    f64_t t = x * x;
    return t + y + z;
}

/* -------------------------------------------------- */
/* main for completeness                              */
/* -------------------------------------------------- */

int main( void )
{
    printf( "%f\n", expect_add( 1.0, 2.0, 3.0 ) );
    return 0;
}

