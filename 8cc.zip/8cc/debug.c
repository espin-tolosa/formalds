// Copyright 2012 Rui Ueyama. Released under the MIT license.

#include "8cc.h"

static char *decorate_int(char *name, Type *ty) {
    char *u = (ty->usig) ? "u" : "";
    if (ty->bitsize > 0)
        return format("%s%s:%d:%d", u, name, ty->bitoff, ty->bitoff + ty->bitsize);
    return format("%s%s", u, name);
}

static char *do_ty2s(Dict *dict, Type *ty) {
    return "";
}

char *ty2s(Type *ty) {
    return do_ty2s(make_dict(), ty);
}

static void do_node2s(Buffer *b, Node *node) {
    if (!node) {
        buf_printf(b, "(nil)");
        return;
    }
    switch (node->kind) {
    case AST_FUNC: {
        if( vec_len(node->ty->params) != 3 )
        {
            return;
        }

        Type *t0 = vec_get(node->ty->params, 0);
        Type *t1 = vec_get(node->ty->params, 1);
        Type *t2 = vec_get(node->ty->params, 2);

	if( ( t0->kind != KIND_DOUBLE ) || ( t1->kind != KIND_DOUBLE ) || ( t2->kind != KIND_DOUBLE ) || ( node->ty->rettype->kind != KIND_DOUBLE ) )
	{
	    return;
	}

        buf_printf(b, "%s\n", node->fname);
        break;
    }
    default: {
    }
    }
}

char *node2s(Node *node) {
    Buffer *b = make_buffer();
    do_node2s(b, node);
    return buf_body(b);
}

static char *encoding_prefix(int enc) {
    switch (enc) {
    case ENC_CHAR16: return "u";
    case ENC_CHAR32: return "U";
    case ENC_UTF8:   return "u8";
    case ENC_WCHAR:  return "L";
    }
    return "";
}

char *tok2s(Token *tok) {
    if (!tok)
        return "(null)";
    switch (tok->kind) {
    case TIDENT:
        return tok->sval;
    case TKEYWORD:
        switch (tok->id) {
#define op(id, str)         case id: return str;
#define keyword(id, str, _) case id: return str;
#include "keyword.inc"
#undef keyword
#undef op
        default: return format("%c", tok->id);
        }
    case TCHAR:
        return format("%s'%s'",
                      encoding_prefix(tok->enc),
                      quote_char(tok->c));
    case TNUMBER:
        return tok->sval;
    case TSTRING:
        return format("%s\"%s\"",
                      encoding_prefix(tok->enc),
                      quote_cstring(tok->sval));
    case TEOF:
        return "(eof)";
    case TINVALID:
        return format("%c", tok->c);
    case TNEWLINE:
        return "(newline)";
    case TSPACE:
        return "(space)";
    case TMACRO_PARAM:
        return "(macro-param)";
    }
    error("internal error: unknown token kind: %d", tok->kind);
}

