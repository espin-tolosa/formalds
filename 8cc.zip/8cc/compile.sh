#!/bin/bash

CC=x86_64-w64-mingw32-gcc-13-win32

CFLAGS="-std=c99 -O0"

$CC $CFLAGS -c buffer.c   -o buffer.o
$CC $CFLAGS -c cpp.c      -o cpp.o
$CC $CFLAGS -c debug.c    -o debug.o
$CC $CFLAGS -c dict.c     -o dict.o
$CC $CFLAGS -c encoding.c -o encoding.o
$CC $CFLAGS -c error.c    -o error.o
$CC $CFLAGS -c file.c     -o file.o
$CC $CFLAGS -c gen.c      -o gen.o
$CC $CFLAGS -c lex.c      -o lex.o
$CC $CFLAGS -c main.c     -o main.o
$CC $CFLAGS -c map.c      -o map.o
$CC $CFLAGS -c parse.c    -o parse.o
$CC $CFLAGS -c path.c     -o path.o
$CC $CFLAGS -c set.c      -o set.o
$CC $CFLAGS -c vector.c   -o vector.o

$CC buffer.o cpp.o debug.o dict.o encoding.o error.o file.o gen.o lex.o main.o map.o parse.o path.o set.o vector.o -o 8cc

