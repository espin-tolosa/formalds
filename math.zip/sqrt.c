#include "dmath.h"

static double my_sqrt_imp( double x );

extern double d_sqrt( double x )
{	
	dnorm_t result = { 0 };

	result.type 		= d_type( x );
	result.f.w[ W0 ] 	= result.type;

	switch( result.type )
	{
		case(GRADZ):
		case (FINITE):
		{
			dnorm_t xn = d_normalize( x );

			const short scale	= xn.e < 0 ? 0 : 2;

			int e 		= xn.e % 2 ? xn.e / 2 : ( 1 + xn.e ) / 2;
			
			e = e < 0 ? -e : e;

			result.f.d = my_sqrt_imp( xn.f.d );
			
			if( xn.e % 2 != 0 )
			{
				result.f.d = result.f.d * invsqrt2;
			}
			
			for(int i = 0; i < e; i++)
			{
				result.f.d = d_setexp(result.f.d, scale);
			}

			break;
		}

		case (INF):
		{
			if( x < 0.0 ) result.f.w[ W0 ] = NAN;
			break;
		}

		case (ZERO):
		{
			result.f.d =  0.0;
			break;
		}

		default: /* NOP */
	}

	return ( result.f.d );
}

static double my_sqrt_imp( double x )
{
	static const double a = 0.42578;
	static const double b = 0.57422;
		
	double yn = a + b * x; /* Lyusternik 1965 */

	yn = 0.5 * ( yn + x / yn);
	yn = 0.5 * ( yn + x / yn);
	yn = 0.5 * ( yn + x / yn);

	return yn;
}