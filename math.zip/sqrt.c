#include "dmath.h"

static double d_sqrt_imp( double x );

static const double sqrt2 = 1.41421356237309505;

extern double d_sqrt( double x )
{	
	dnorm_t result = { 0 };

	result.type 		= d_type( x );
	result.f.w[ W0 ] 	= result.type;

	switch( result.type )
	{
		case(GRADZ):
		case (FINITE):
		{
			dnorm_t xn = d_normalize( x );

			result.f.d = d_sqrt_imp( xn.f.d );

			if( xn.e % 2 != 0 )
			{
				result.f.d = result.f.d * sqrt2;
				xn.e = xn.e + 1;
				xn.e = xn.e >> 1;
			}
			else
			{
				xn.e = xn.e >> 1;
				xn.e = xn.e + 1;
			}
				result.f.d = result.f.d * d_setexp(1., xn.e);

			break;
		}

		case (INF):
		{
			if( x < 0.0 ) result.f.w[ W0 ] = NAN;
			break;
		}

		case (ZERO):
		{
			result.f.d =  0.0;
			break;
		}

		default: /* NOP */
	}

	return ( result.f.d );
}

static double d_sqrt_imp( double x )
{
	double y;

	y = (-0.1984742 * x + 0.8804894) * x + 0.3176687;
	y = 0.5 * (y + x / y);
	y = y + x / y;
	x = 0.25 * y + x / y;
	
	return (x);
}