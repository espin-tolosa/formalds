#include <assert.h>
#include <stdio.h>
#include "public_math.h"
#include "dmath.h"

double sqrt(double x);
double pow(double x, double y);
double exp(double x);
double log(double x);
double sin(double x);
double cos(double x);
double asin(double x);
double fabs(double x);

/*
 * ------------------------------------------
 * |				TEST					|
 * ------------------------------------------
 */

void test_fun( const char * fname, double (*fp) (double), double (*th) (double), double xmin, double xmax, double dx )
{
	unsigned long long total = 0;
	unsigned long long equal = 0;

	double maxerr = 0.0;

	FILE * file = fopen("test_result.txt", "a");

	for(double x = xmin; x < xmax; x+= dx)
	{
		total++;

		const double fx = fp( x );
		const double ft = th( x );

		const u16_t fx_type = d_type( fx );
		const u16_t ft_type = d_type( ft );

		if( fx_type == ft_type )
		{
			if( fx_type == NAN &&  ft_type == NAN )
			{
				equal++;
			}

			else if( fx_type == FINITE && ft_type == FINITE )
			{
				double res = ( fx - ft ) / ft;
				
				res = res < 0.0 ? -res : res;
				
				if ( res < 1.e-15 )
				{
					equal++;
				}
				else
				{
					fprintf(file, "FAILED: %s (%.15e): expected = %.15e, given = %.15e, tol = %.e\n", fname, x, ft, fx, res );
				}

				maxerr = res > maxerr ? res : maxerr;
			}

			else if( fx_type == ZERO && ft_type == ZERO )
			{
				equal++;
			}

			else if( fx_type == GRADZ && ft_type == GRADZ )
			{
				equal++;
			}

			else if( fx_type == INF && ft_type == INF )
			{
				if( fx < 0.0 && ft < 0.0)
				{
					equal++;
				}
				
				else if( fx > 0.0 && ft > 0.0)
				{
					equal++;
				}

				else
				{
					fprintf(file, "FAILED: %s (%.15e): expected = %.15e, given = %.15e\n", fname, x, ft, fx );
				}
			}

			else
			{
				fprintf(file, "FAILED: %s (%.15e): expected = %.15e, given = %.15e\n", fname, x, ft, fx );
			}
		}
	}

	fprintf(file, "TEST %s finished: maxerro = %.e in range x = [%.e, %.e]\n", fname, maxerr, xmin, xmax);

	fclose(file);
}



void test_sqrt( void )
{
	int total = 0;
	int equal = 0;
	
	double xmin = 0.0;
	double xmax = 1000.0;
	double delta = 0.001;

	for(double x = xmin; x < xmax; x+= delta)
	{
		total++;

		volatile double sqrtx2  = d_sqrt( x * x );
		double res =  sqrtx2 - x;

		res = res < 0.0 ? -res : res;

		if ( res < 1.e-15 )
		{
			equal++;
		}
		else
		{
			printf("FAILED: sqrt(%.12f) = %.12f\n", x, sqrtx2); 
		}
	}

	assert( equal == total );
//	printf("SQRT(x)^2 x = [%f, %f), equal: %d of %d, (%f x100)\n", xmin, xmax, equal, total, ((double)equal/(double)total)*100.0);
}

void test_log( void )
{
	int total = 0;
	int equal = 0;
	
	double xmin = 1.e-40;
	double xmax = 1024.0;
	double delta = 0.0001;

	for(double x = xmin; x < xmax; x+= delta)
	{
		total++;

		double zero  = d_log( x ) +  d_log( 1. / x );
		double res =  zero;

		res = res < 0.0 ? -res : res;

		if ( res < 1.e-15 )
		{
			equal++;
		}
		else
		{
			printf("FAILED: log(%.12f) = %.12f, zero = %.12f\n", x, d_log(x), res); 
		}
	}

	assert( equal == total );
//	printf("SQRT(x)^2 x = [%f, %f), equal: %d of %d, (%f x100)\n", xmin, xmax, equal, total, ((double)equal/(double)total)*100.0);
}

void test_exp( void )
{
	int total = 0;
	int equal = 0;
	
	double xmin = -0.35;
	double xmax = +0.35;
	double delta = 0.0000001;

	for(double x = xmin; x < xmax; x+= delta)
	{
		total++;

		volatile double one  = d_exp( x ) * d_exp( -x );
		double res =  one - 1.0;

		res = res < 0.0 ? -res : res;

		if ( res < 1.e-15 )
		{
			equal++;
		}
		else
		{
			printf("FAILED: exp(%.12f) = %.12f\n", x, d_exp(x)); 
		}
	}

	assert( equal == total );

	assert( d_exp(  0.    	) 	== 1.0 		); /* exp(  0 ) = 1 */
	assert( d_exp( -1./0. 	) 	== 0.0 		); /* exp( -∞ ) = 0 */
	assert( d_exp( +1./0. 	) 	== 1./0. 	); /* exp( +∞ ) = ∞ */
	assert( d_exp( +1.e-320 ) 	== 1.0 		); /* exp( +u ) = 1 */
	assert( d_exp( -1.e-320 ) 	== 1.0 		); /* exp( -u ) = 1 */
	assert( d_exp( +1.e-16 ) 	== 1.0 		); /* exp( +o ) = 1 */
	assert( d_exp( -1.e-16 ) 	== 1.0 		); /* exp( -o ) = 1 */
}

void test_sin( void )
{
	int total = 0;
	int equal = 0;
	
	double xmin = -1.57079; /* -inf round -pi/2 */
	double xmax = +1.57080; /* +inf round +pi/2 */
	double delta = 0.0001;

	for(double x = xmin; x < xmax; x+= delta)
	{
		total++;

		volatile double zero  = d_sin( -x ) + d_sin( x );
		double res =  zero;

		res = res < 0.0 ? -res : res;

		if ( res < 1.e-15 )
		{
			equal++;
		}
		else
		{
			printf("FAILED: exp(%.12f) = %.12f\n", x, d_exp(x)); 
		}
	}

	assert( equal == total );

	assert( d_sin(  0.    	) 	== 0.0 		); /* sin(  0 ) = 0 */
	assert( d_sin( -1./0. 	) 	== 1.0 - 1.0); /* sin( -∞ ) = NaN */
//	assert( d_sin( +1./0. 	) 	== 1./0. 	); /* sin( +∞ ) = ∞ */
//	assert( d_sin( +1.e-320 ) 	== 1.0 		); /* sin( +u ) = 1 */
//	assert( d_sin( -1.e-320 ) 	== 1.0 		); /* sin( -u ) = 1 */
//	assert( d_sin( +1.e-16 ) 	== 1.0 		); /* sin( +o ) = 1 */
//	assert( d_sin( -1.e-16 ) 	== 1.0 		); /* sin( -o ) = 1 */
}

void test_setexp(void)
{
	//	SETEXP(X,N): returns the floating-point representation of a number whose significand is the significand of the floating-point number X, and whose exponent is the integer N.
	//	an operation that returns the floating-point number with the same significand as X, and with exponent N.
	//	Floating-point number representation: the bit or digit pattern representing a floating-point number. Although the details of the representation may vary from machine to machine, every non-zero floating-point number can be thoruhgt of as being represented in the form: x = ±f·B^e, 1/B <= f < 1

	assert(0.0625 		== d_setexp(1.0  , -3)); // 1 		= (0.5)*2^1 		-> (0.5)*2^-3 		= 0.0625
	assert(4.0    		== d_setexp(1.0  ,  3)); // 1 		= (0.5)*2^1 		-> (0.5)*2^+3 		= 4.0
	assert(1.9234375	== d_setexp(123.1,  1)); // 123.1 	= (0.96171875)*2^7 	-> (0.9617875)*2^1 	= 1.923475
}

void draw_fun( const char * fname, double (*fp) (double), double xmin, double xmax, double dx )
{
	FILE * file = fopen(fname, "w");

	for(double x = xmin; x <= xmax; x+=dx)
	{
		const double y = fp(x);
		fprintf(file,"%.12e, %.12e\n", x, y);
		printf("%s( %.12e ) = %.12e\n", fname, x, y);
	}

	fclose(file);
}

double d_pow2(double x)
{
	return d_pow(2.7182818284,x);
}

int main( void )
{
	FILE * file = fopen("test_result.txt", "w");
	fprintf(file, "Report\n");
	fclose(file);

	test_fun("SQRT", d_sqrt, sqrt, 0.0, 100., 0.1);
	test_fun("EXP", d_exp, exp, 0.0, 100., 0.1);

	//printf("TODO: review gradual underflow: sqrt(%.12e) = %.12e\n", 1.e-320, d_sqrt(1.e-320));
	//draw_fun("LOG.csv",d_log, 1.e-40, 1024., 0.001);
	//draw_fun("POW2.csv",d_pow2, -10., 10., 1);
	//draw_fun("ASIN.csv", d_asin, -1.0, 1.0, 0.1);
	//d_pow(12.0, 2.0);


//
//	printf("test_dpow(2.0, 2.0) =%f\n", d_pow(2.0, 2.0));

	test_sqrt();
//	test_exp();
//	test_log();
//	test_sin();


#if 0
	double twobypi = 0.6366197723675813430755350;
	double pi = 3.1415926535897932384;
	double x = twobypi + 0.0001;

	double g 	= x * twobypi; // g = x / 0.5pi
	long quad 	= (long)(0 < g ? g + 0.5 : g - 0.5); //

	printf("x = %f, g = %f, quad = %ld\n",x, g, quad );
	
	printf("SIN\n");

//	d_sin(1.6);
	double min_sin_err = 1000.0;
	double max_sin_err = 0.0;

	double min_cos_err = 1000.0;
	double max_cos_err = 0.0;

	for(double x = -6.3 ; x < 6.3; x+=0.2)
	{
		const double err_sin = sin(x) - d_sin(x);
		const double abs_err_sin = err_sin < 0. ? -err_sin : err_sin;
		max_sin_err = max_sin_err < abs_err_sin ? abs_err_sin : max_sin_err;
		min_sin_err = abs_err_sin < min_sin_err ? abs_err_sin : min_sin_err;

		const double err_cos = cos(x) - d_cos(x);
		const double abs_err_cos = err_cos < 0. ? -err_cos : err_cos;
		max_cos_err = max_cos_err < abs_err_cos ? abs_err_cos : max_cos_err;
		min_cos_err = abs_err_cos < min_cos_err ? abs_err_cos : min_cos_err;

		printf("%.12f, %.12f, %.12f\n",x, d_sin(x), d_cos(x));
	}


	printf("ABS ERROR: MAX = %e, MIN = %e\n", max_sin_err, min_sin_err);
	printf("ABS ERROR: MAX = %e, MIN = %e\n", max_cos_err, min_cos_err);

	double x;
	dnorm_t xn;

	x = -1.e-309; xn = d_normalize(x); printf("%.12e = %.12e x 2 ^ %d = %.12e\n", x, xn.f.d, xn.e, xn.f.d*pow(2.0, xn.e));
	
	x = 0.0; 			assert( ZERO 	== d_type(x));
	x = 1./0.; 			assert( INF 	== d_type(x));
	x = -1./0.; 		assert( INF 	== d_type(x));
	x = -1./-0.; 		assert( INF 	== d_type(x));
	x = 1./0. + 1./0.; 	assert( INF 	== d_type(x));
	x = 1.e-320; 		assert( GRADZ 	== d_type(x));
	x = 1./0. - 1./0.; 	assert( NAN 	== d_type(x));
	x = 0.0*(1./0.); 	assert( NAN 	== d_type(x));
	x = 1.0; 			assert( FINITE 	== d_type(x));
	x = -1.E12; 		assert( FINITE 	== d_type(x));
	x = 1. - 1.; 		assert( ZERO 	== d_type(x));

	x = +120.0; xn = d_normalize(x); assert( xn.f.d == +0.9375 && xn.e == 7 && xn.type == FINITE ); //printf("frac = %.12f, exp = %d\n", xn.f, xn.e);
	x = -120.0; xn = d_normalize(x); assert( xn.f.d == -0.9375 && xn.e == 7 && xn.type == FINITE );
	x = -0.01 ; xn = d_normalize(x); assert( xn.f.d == -0.64   && xn.e == -6 && xn.type == FINITE );
	x = 0.5e-10 ; xn = d_normalize(x); assert( xn.f.d == 0.8589934592 && xn.e == -34 && xn.type == FINITE );
	x = 1./0. ; xn = d_normalize(x); assert( xn.f.d == 1./0.   && xn.e == 0 && xn.type == INF );

	x = 4.9E-324;
	xn = d_normalize(x);

	return 0;
#endif
}
