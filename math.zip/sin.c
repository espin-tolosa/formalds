#include "dmath.h"

/* Cody and Waite */
static const f64_t c1;
static const f64_t c2;
static const f64_t c1 = 3294198.0 / 2097152.0;
static const f64_t c2 = 3.139164786504813217e-7;

static const f64_t c[8] =
{
	-0.000000000011470879,
	+0.000000002087712071,
	-0.000000275573192202,
	+0.000024801587292937,
	-0.001388888888888893,
	+0.041666666666667325,
	-0.500000000000000000,
	+1.0,
};

static const f64_t s[8] =
{
	-0.000000000000764723,
	+0.000000000160592578,
	-0.000000025052108383,
	+0.000002755731921890,
	-0.000198412698412699,
	+0.008333333333333372,
	-0.166666666666666667,
	+1.0,
};

#define MASK_COS 0x1
#define MASK_SIN 0x2
#define MASK_ALL 0x3

typedef enum
{
	SIN_QUADRANT_OFFSET = 0,
	COS_QUADRANT_OFFSET = 1,
} qoff_t;

static const f64_t twobypi = 0.63661977236758134308;

static f64_t d_sin_impl(f64_t x, qoff_t qoff);

f64_t d_sin(f64_t x)
{
	dnorm_t result = { 0 };

	result.type 		= d_type( x );
	result.f.w[ W0 ] 	= result.type;

	switch(result.type)
	{
		case(INF):
		{
			result.f.w[ W0 ] = NAN;
			break;
		}
		
		case(NAN):
		{
			result.f.w[ W0 ] = NAN;
			break;
		}
		
		case(GRADZ):
		{
			result.f.d = x;
			break;
		}
		
		case(ZERO):
		{
			result.f.d = 0.0;
			break;
		}

		case(FINITE):
		{
			const dw_t y = { .d = x };

			if( (y.w[ W0 ] & DMASK) < 0x4120 ) /* |x| < 2**20 */
			{
				if( y.w[ W0 ] & SMASK )
				{
					result.f.d = -d_sin_impl(-x, SIN_QUADRANT_OFFSET);
				}
				else
				{
					result.f.d = d_sin_impl(x, SIN_QUADRANT_OFFSET);
				}
			}
			else
			{
				result.f.w[ W0 ] = NAN;
			}

			break;
		}
		
		default:
		{
			result.f.w[ W0 ] = NAN;
		}
	}

	return ( result.f.d );
}

f64_t d_cos(f64_t x)
{
	dnorm_t result = { 0 };

	result.type 		= d_type( x );
	result.f.w[ W0 ] 	= result.type;
	
	switch(result.type)
	{
		case(INF):
		{
			result.f.w[ W0 ] = NAN;
			break;
		}
		
		case(NAN):
		{
			result.f.w[ W0 ] = NAN;
			break;
		}
		
		case(GRADZ):
		{
			result.f.d = 1.0;
			break;
		}
		
		case(ZERO):
		{
			result.f.d = 1.0;
			break;
		}

		case(FINITE):
		{
			const dw_t y = { .d = x };

			if( (y.w[ W0 ] & DMASK) < 0x4120 ) /* |x| < 2**20 */
			{
				if( y.w[ W0 ] & SMASK )
				{
					result.f.d = d_sin_impl(-x, COS_QUADRANT_OFFSET);
				}
				else
				{
					result.f.d = d_sin_impl(x, COS_QUADRANT_OFFSET);
				}
			}
			else
			{
				result.f.w[ W0 ] = NAN;
			}

			break;
		}
		
		default:
		{
			result.f.w[ W0 ] = NAN;
		}
	}

	return ( result.f.d );
}

static u64_t int_near_round( f64_t x )
{
	f64_t y;

	if( x < 0.0 )
	{
		y = -x + 0.5;
	}
	else
	{
		y = x + 0.5;
	}

	return ((u64_t) y); /* This casting is mandatory, it was assumed x < 2**20 */
}

static f64_t d_sin_impl(f64_t x, qoff_t qoff)
{
	const u64_t k 	= int_near_round( x * twobypi ) ;
	const u32_t q 	= qoff + ( k & MASK_ALL );

	//i32_t sign = 1;

	f64_t g = ( x - (f64_t) k * c1) - (f64_t)k * c2;

	if ( q & MASK_COS && -DBL_EPS < g && g < DBL_EPS )
	{
		g = 1.0;
	}

	if ( q & MASK_COS )
	{
		g = d_horner(g * g, c, 8);
	}

	else
	{
		g = g * d_horner(g * g, s, 8);
	}

	if( q & MASK_SIN )
	{
		g = -g;
	}
	else
	{
		g = g;
	}

	return ( g );
}
