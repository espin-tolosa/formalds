#include "dmath.h"

extern double d_sqrt    ( double x );
double sqrt(double x);

static const double p[5] =
{
	-0.69674573447350646411E+0,
	 0.10152522233806463645E+2,
	-0.39688862997504877339E+2,
	 0.57208227877891731407E+2,
	-0.27368494524164255994E+2
};

static const double q[6] =
{
	 0.10000000000000000000E+1,
	-0.23823859153670238830E+2,
	 0.15095270841030604719E+3,
	-0.38186303361750149284E+3,
	 0.41714430248260412556E+3,
	-0.16421096714498560795E+3
};

static const double pio4   = 0.78539816339744830962;

static double d_asin_impl(double y, i32_t idx);

extern double d_asin ( double x )
{
    dnorm_t result = { 0 };

	result.type 		= d_type( x );
	result.f.w[ W0 ] 	= result.type;

	switch( result.type )
    {
        case (GRADZ):
		case (FINITE):
		{
            result.f.d = d_asin_impl(x, 0);
			break;
		}

		case (ZERO):
        {
            result.f.d = 0.0;
            break;
        }
	
    	case (INF):
        case (NAN):
		{
            result.f.w[ W0 ] = NAN;
			break;
		}
    }

    return ( result.f.d );
}

static double d_asin_impl(double x, i32_t idx)
{
    dw_t result;

    double y = x;

    if (x < 0.0)
    {
        y   = -x;
        idx = idx | 2;
    }

    else { /* NOP */}

    if (y < DBL_SQE)
    {
        /* NOP */
    }

    else if (y < 0.5)
    {
        const double g  = y * y;
        const double pg = d_horner(g, p, 5);
        const double pq = d_horner(g, q, 6);

        y = y + ( y * g * pg / pq );
    }

    else if (y < 1.0)
    {
        const double g = (1.0 - y) / 2.0;
        const double pg = d_horner(g, p, 5);
        const double pq = d_horner(g, q, 6);

        idx = idx | 4;

        y = sqrt(g);
        y = y + y;
        y += y * g * pg / pq;
    }

    else if (y == 1.0)
    {
        idx = idx | 4;
        y = 0.0;
    }

    else
    {
        idx = -1;
    }

	switch (idx)
	{
	    case 0:
        {
            result.d = y;
            break;
        }

        case 2:
        {
            result.d = -y;
            break;
        }

        case 4:
        {
            result.d = (pio4 - y) + pio4;
            break;
        }

        case 6:
        {
            result.d = (-pio4 + y) - pio4;
            break;
        }

        default:
        {
            result.w[ W0 ] = NAN;
        }
	}

    return result.d;
}