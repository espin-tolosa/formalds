#include "dmath.h"
#include <stdio.h>

//static double d_pow_impl(double x, double y);
static double d_pow_impl_v2(double x, double y);
extern double d_reduce(double v);
short _Dint(double *px, short xexp);
extern double d_exp( double x );
extern double d_log( double x );

extern double d_pow(double x, double y)
{
    dnorm_t result = { 0 };

	result.type 		= d_type( x );
	result.f.w[ W0 ] 	= result.type;

	switch( result.type )
    {
		case (FINITE):
		{
			if( x > 0.0 )
			{
                result.f.d = d_pow_impl_v2(x, y);
			}
			else
			{
                result.f.w[ W0 ] = NAN;
			}

			break;
		}

		case (INF):
        case (NAN):
		case (ZERO):
		case (GRADZ):
		{
            result.f.w[ W0 ] = NAN;
			break;
		}
    }

    return result.f.d;
}

#if 0
static double d_pow_impl(double x, double y)
{
    static const double a1[17] =
    {
        1.000000000000000000000000000000000000000000000000000e+00,
        9.576032806985737000360359161277301609516143798828125e-01,
        9.170040432046712153280054735660087317228317260742188e-01,
        8.781260801866497267553768324432894587516784667968750e-01,
        8.408964152537145020360753733257297426462173461914063e-01,
        8.052451659746271417361640487797558307647705078125000e-01,
        7.711054127039703720569718825572635978460311889648438e-01,
        7.384130729697496731134265246510040014982223510742188e-01,
        7.071067811865475727373109293694142252206802368164063e-01,
        6.771277734684463256442654710554052144289016723632813e-01,
        6.484197773255048202756256614520680159330368041992188e-01,
        6.209289060367420010067007751786150038242340087890625e-01,
        5.946035575013605134486738279520068317651748657226563e-01,
        5.693943173783457822878517617937177419662475585937500e-01,
        5.452538663326288448374157269427087157964706420898438e-01,
        5.221368912137068774015347116801422089338302612304688e-01,
        5.000000000000000000000000000000000000000000000000000e-01,
     };

    static const double a2[8] =
    {
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
    };

	static const double p1 = 0.83333333333333211405E-1;
	static const double p2 = 0.12500000000503799174E-1;
	static const double p3 = 0.22321421285924258967E-2;
	static const double p4 = 0.43445775672163119635E-3;

	static const double q1 = 0.69314718055994529629E+0;
	static const double q2 = 0.24022650695909537056E+0;
	static const double q3 = 0.55504108664085595326E-1;
	static const double q4 = 0.96181290595172416964E-2;
	static const double q5 = 0.13333541313585784703E-2;
	static const double q6 = 0.15400290440989765601E-3;
	static const double q7 = 0.14928852680595608186E-4;

	static const double k  = 0.44269504088896340763E+0;

//
    dnorm_t xn = d_normalize( x );

//5
    const double g = d_setexp(x, 0);

//6
    short int p = 1;

    if( g <= a1[9-1] )
    {
        p = 9;
    }

    if( g <= a1[p+4-1] )
    {
        p = p + 4;
    }

    if( g <= a1[p+2-1] )
    {
        p = p + 2;
    }

//7
    double z = ((g - a1[p+1]) - a2[(p+1)/2]) / (g + a1[p+1]);

    printf("x = %f, p = %d, a1[p+1] = %f, a2[(p+1)/2] =%f,  g = %f, z = %f ", x, p, a1[p+1], a2[(p+1)/2], g, z);
    z = z + z;

//8
    double v = z * z;
    double R  = (((p4 * v + p3) * v + p2) * v + p1) * v * z;

    R = R + k * R;

    double u2 = (R + z * k) + z;

//9
    double u1 = ((double)(xn.e * 16 - p )) * 0.0625;

    double w = y * (u1 + u2);

    double w1 = d_reduce(w);
    double w2 = w - w1;
    int   iw1 = (int)w1;

    if(w < 0.0001 || 1.e10 < w)
    {
        return 0.0; // TODO: handle this step 12
    }

    iw1 = iw1 + 1;

    int I;

    if(iw1 < 0.0)
    {
        I = 0;
    }
    else
    {
        I = 1;
    }

    int m_ = iw1 / 16 + I;
    int p_ = 16*m_ - iw1;

    z = ((((((q7 * w2 + q6) * w2 + q5) * w2 + q4) * w2 + q3) * w2 + q2) * w2 + q1) * w2;

    z = 1.0 + z;

    z = z * a1[p_ + 1] + a1[p_ + 1];

    dnorm_t zn = d_normalize(z);

    printf("\n");

    return d_setexp(z, m_ + zn.e);
}
#endif

#define SAFE_EXP 1000
#define HUGE_EXP 80

static double d_pow_impl_v2(double x, double y)
{
	double yi = y;
	double yx, z;
	short n, xexp, zexp;
	short neg = 0;
    dnorm_t xn = d_normalize(x);

    xexp = xn.e;

	static const short shuge = HUGE_EXP;
	//static const double dhuge = (double)HUGE_EXP;
	static const double ln2 = 0.69314718055994530942;
	//static const double rthalf = 0.70710678118654752440;

		{	/* y*log2(x) may be reasonable */
		double dexp = (double)xexp;
		long zl = (long)(yx = y * dexp);

		if (zl != 0)
			{	/* form yx = y*xexp-zl carefully */
			yx = y;
            _Dint(&yx, 16);
			yx = (yx * dexp - (double)zl) + (y - yx) * dexp;
			}
		yx *= ln2;
		zexp = zl <= -shuge ? -shuge : zl < shuge ? zl : shuge;
		if ((n = (short)y) < -SAFE_EXP || SAFE_EXP < n)
			n = 0;
		}
	 {	/* compute z = xfrac^n * 2^yx * 2^zexp */
	z = 1.0;
	if (x != 1.0)
		{	/* z *= xfrac^n */
		if ((yi = y - (double)n) != 0.0)
			yx += d_log(x) * yi;
		if (n < 0)
			n = -n;
		for (yi = x; ; yi *= yi)
			{	/* scale by x^2^n */
			if (n & 1)
				z *= yi;
			if ((n >>= 1) == 0)
				break;
			}
		if (y < 0.0)
			z = 1.0 / z;
		}
	if (yx != 0.0)	/* z *= 2^yx */
		z = d_exp(yx) < 0 ? z * yx : y < 0.0 ? 0.0 : 1./0.;
	if (0 <= d_setexp(z, zexp))	/* z = z * 2^zexp */
    {
		//errno = ERANGE;	/* underflow or overflow */

    }
	return (neg ? -z : z); 
    }
}

extern double d_reduce(double v)
{
    return (double) ((int)(16.0 * v)) * 0.0625;
}

extern double d_setexp(double x, signed short n)
{
    dw_t result;

    dw_t f = { .d = x };

    result.w[ W3 ] = f.w[ W3 ];
    result.w[ W2 ] = f.w[ W2 ];
    result.w[ W1 ] = f.w[ W1 ];
    result.w[ W0 ] = ( f.w[ W0 ] & MMASK ) | ( ( n + DBIAS ) << DOFF ) ;

    return result.d;
}

short _Dint(double *px, short xexp)
	{	/* test and drop (scaled) fraction bits */
	unsigned short *ps = (unsigned short *)px;
	unsigned short frac = ps[ W0] & DFRAC
		|| ps[ W1] || ps[ W2] || ps[ W3];
	short xchar = (ps[ W0 ] & DMASK) >> DOFF;

	if (xchar == 0 && !frac)
		return (0);	/* zero */
	else if (xchar != DMAX)
		;	/* finite */
	else if (!frac)
		return (INF);
	else
		{	/* NaN */
		return (NAN);
		}
	xchar = (DBIAS+48+DOFF+1) - xchar - xexp;
	if (xchar <= 0)
		return (0);	/* no frac bits to drop */
	else if ((48+DOFF) < xchar)
		{	/* all frac bits */
		ps[W0] = 0, ps[W1] = 0;
		ps[W2] = 0, ps[W3] = 0;
		return (FINITE);
		}
	else
		{	/* strip out frac bits */
		static const unsigned short mask[] = {
			0x0000, 0x0001, 0x0003, 0x0007,
			0x000f, 0x001f, 0x003f, 0x007f,
			0x00ff, 0x01ff, 0x03ff, 0x07ff,
			0x0fff, 0x1fff, 0x3fff, 0x7fff};
		static const size_t sub[] = {W3, W2, W1, W0};

		frac = mask[xchar & 0xf];
		xchar >>= 4;
		frac &= ps[sub[xchar]];
		ps[sub[xchar]] ^= frac;
		switch (xchar)
			{	/* cascade through! */
		case 3:
			frac |= ps[W1], ps[W1] = 0;
		case 2:
			frac |= ps[W2], ps[W2] = 0;
		case 1:
			frac |= ps[W3], ps[W3] = 0;
			}
		return (frac ? FINITE : 0);
		}
	}

// emin = -126

// e = n - emin + 1

// n = 3 -> e = 3 + 126 + 1 = 130

// n = 17 -> e = 17 + 126 + 1 = 144

// n = -111 -> e = -111 + 126 + 1 = 