#include "dmath.h"

//static double d_log_imp( double x );
static double d_log_imp_cody( double x );

extern double d_log( double x )
{	
	dnorm_t result = { 0 };

	result.type 		= d_type( x );
	result.f.w[ W0 ] 	= result.type;

	switch( result.type )
	{
		case (FINITE):
		{
			if( x < 0.0 )
			{
				result.f.w[ W0 ] = NAN;
			}
			else
			{
				result.f.d = d_log_imp_cody( x );
			}

			break;
		}

		case (INF):
		{
			if( x < 0 ) result.f.w[ W0 ] = NAN;
			break;
		}

		case(GRADZ):
		case (ZERO):
		{
			result.f.w[ W0 ] = NAN;
			break;
		}

		default: /* NOP */
	}

	return result.f.d;
}

static double d_log_imp_cody( double x )
{
	static const double a0 		= -0.64124943423745581147E+2;
	static const double a1 		= +0.16383943563021534222E+2;
	static const double a2 		= -0.78956112887491257267E+0;

	static const double b0 		= -0.76949932108494879777E+3;
	static const double b1 		= +0.31203222091924532844E+3;
	static const double b2 		= -0.35667977739034646171E+2;

	static const double c1 		= 22713.0 / 32768.0;
	static const double c2		= 1.428606820309417232e-6;
	//static const double c3		= 0.43429448190325182765;
	static const double sqrt05 	= 0.707106781186547524400;

	dnorm_t xn = d_normalize( x );
	
	double z = xn.f.d - 0.5;

	if( sqrt05 < xn.f.d )
	{
		z = (z - 0.5) / ( (xn.f.d * 0.5) + 0.5 ); 
	}

	else
	{
		xn.e = xn.e - 1;
		z = z / ( ( z * 0.5 ) + 0.5 ); 
	}

	const double w	= z * z;
	const double aw = (( w + a2 ) * w + a1 ) * w + a0;
	const double bw = (( w + b2 ) * w + b1 ) * w + b0;
	const double rz = z + z * ( w * aw / bw );

	const double result = ( xn.e * c2 + rz) + xn.e * c1;

	return ( result );
}

/*
static double d_log_imp( double x )
{
	const double ln2 = 0.69314718055994530941723212145818;

	dnorm_t xn = d_normalize( x );
	dnorm_t gn = d_normalize( xn.f.d );

	dnorm_t result = { 0 };

	result.type 		= d_type( x );
	result.f.w[ W0 ] 	= result.type;
	
	double f = gn.f.d;

	double z = 2.0 * ( f - 1.0 ) / ( f + 1.0 );

	double yn = z;

	z = z * z * z;
	yn = yn + z / 12.0;
	
	z = z * z * z;
	yn = yn + z / 80.0;

	z = z * z * z;
	yn = yn + z / 448.0;
	
	z = z * z * z;
	yn = yn + z / 2304.0;
	
	z = z * z * z;
	yn = yn + z / 11264.0;

	z = z * z * z;
	yn = yn + z / 49811.282184751;

	return ( ( xn.e - gn.e ) * ln2 + yn );
}
*/