#ifndef PUBLIC_MATH_H
#define PUBLIC_MATH_H

extern double d_sqrt    ( double x );
extern double d_exp     ( double x );
extern double d_log     ( double x );
extern double d_cos     ( double x );
extern double d_sin     ( double x );
extern double d_asin    ( double x );

#endif