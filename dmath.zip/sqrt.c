#include "dmath.h"

static double my_sqrt_imp( double x );

extern double d_sqrt( double x )
{
	dnorm_t xn = d_normalize( x );
	
	dnorm_t result = { 0 };

	result.type 		= d_type( x );
	result.f.w[ W0 ] 	= result.type;

	if ( result.type == FINITE || result.type == GRADZ )
	{
		const float scale	= xn.e < 0 ? 0.5 : 2.0;

		int e 		= xn.e % 2 ? xn.e / 2 : ( 1 + xn.e ) / 2;
		
		e = e < 0 ? -e : e;

		result.f.d = my_sqrt_imp( xn.f.d );
		
		if( xn.e % 2 != 0 )
		{
			result.f.d = result.f.d * invsqrt2;
		}
		
		for(int i = 0; i < e; i++)
		{
			result.f.d = result.f.d * scale;
		}
	}
	
	return ( result.f.d );
}

static double my_sqrt_imp( double x )
{
	static const double a = 0.42578;
	static const double b = 0.57422;
		
	double yn = a + b * x; /* Lyusternik 1965 */

	yn = 0.5 * ( yn + x / yn);
	yn = 0.5 * ( yn + x / yn);
	yn = 0.5 * ( yn + x / yn);

	return yn;
}