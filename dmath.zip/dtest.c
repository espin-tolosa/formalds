#include <assert.h>

#include "public_math.h"

double sqrt(double x);
double pow(double x, double y);
double sin(double x);
double cos(double x);
int printf(const char * message, ...);

/*
 * ------------------------------------------
 * |				TEST					|
 * ------------------------------------------
 */

void test_sqrt( void )
{
	int total = 0;
	int equal = 0;
	
	double xmin = 0.5;
	double xmax = 1.0;
	double delta = 0.0000001;

	for(double x = xmin; x < xmax; x+= delta)
	{
		total++;

		volatile double sqrtx2  = d_sqrt( x * x );
		double res =  sqrtx2 - x;

		res = res < 0.0 ? -res : res;

		if ( res < 1.e-15 )
		{
			equal++;
		}
		else
		{
			printf("FAILED: sqrt(%.12f) = %.12f\n", x, sqrtx2); 
		}
	}

	assert( equal == total );
//	printf("SQRT(x)^2 x = [%f, %f), equal: %d of %d, (%f x100)\n", xmin, xmax, equal, total, ((double)equal/(double)total)*100.0);
}

void test_log( void )
{
	int total = 0;
	int equal = 0;
	
	double xmin = 16.0;
	double xmax = 240.0;
	double delta = 0.001;

	printf("TODO: tight up log tolerance\n");

	for(double x = xmin; x < xmax; x+= delta)
	{
		total++;

		double zero  = d_log( x * x ) - 2.0 * d_log( x );
		double res =  zero;

		res = res < 0.0 ? -res : res;

		if ( res < 1.e-2 )
		{
			equal++;
		}
		else
		{
			printf("FAILED: log(%.12f) = %.12f, zero = %.12f\n", x, d_log(x), res); 
		}
	}

	assert( equal == total );
//	printf("SQRT(x)^2 x = [%f, %f), equal: %d of %d, (%f x100)\n", xmin, xmax, equal, total, ((double)equal/(double)total)*100.0);
}

void test_exp( void )
{
	int total = 0;
	int equal = 0;
	
	double xmin = -0.35;
	double xmax = +0.35;
	double delta = 0.0000001;

	for(double x = xmin; x < xmax; x+= delta)
	{
		total++;

		volatile double one  = d_exp( x ) * d_exp( -x );
		double res =  one - 1.0;

		res = res < 0.0 ? -res : res;

		if ( res < 1.e-15 )
		{
			equal++;
		}
		else
		{
			printf("FAILED: exp(%.12f) = %.12f\n", x, d_exp(x)); 
		}
	}

	assert( equal == total );

	assert( d_exp(  0.    	) 	== 1.0 		); /* exp(  0 ) = 1 */
	assert( d_exp( -1./0. 	) 	== 0.0 		); /* exp( -∞ ) = 0 */
	assert( d_exp( +1./0. 	) 	== 1./0. 	); /* exp( +∞ ) = ∞ */
	assert( d_exp( +1.e-320 ) 	== 1.0 		); /* exp( +u ) = 1 */
	assert( d_exp( -1.e-320 ) 	== 1.0 		); /* exp( -u ) = 1 */
	assert( d_exp( +1.e-16 ) 	== 1.0 		); /* exp( +o ) = 1 */
	assert( d_exp( -1.e-16 ) 	== 1.0 		); /* exp( -o ) = 1 */
}

void test_sin( void )
{
	int total = 0;
	int equal = 0;
	
	double xmin = -1.57079; /* -inf round -pi/2 */
	double xmax = +1.57080; /* +inf round +pi/2 */
	double delta = 0.0001;

	for(double x = xmin; x < xmax; x+= delta)
	{
		total++;

		volatile double zero  = d_sin( -x ) + d_sin( x );
		double res =  zero;

		res = res < 0.0 ? -res : res;

		if ( res < 1.e-15 )
		{
			equal++;
		}
		else
		{
			printf("FAILED: exp(%.12f) = %.12f\n", x, d_exp(x)); 
		}
	}

	assert( equal == total );

	assert( d_sin(  0.    	) 	== 0.0 		); /* sin(  0 ) = 0 */
	assert( d_sin( -1./0. 	) 	== 1.0 - 1.0); /* sin( -∞ ) = NaN */
//	assert( d_sin( +1./0. 	) 	== 1./0. 	); /* sin( +∞ ) = ∞ */
//	assert( d_sin( +1.e-320 ) 	== 1.0 		); /* sin( +u ) = 1 */
//	assert( d_sin( -1.e-320 ) 	== 1.0 		); /* sin( -u ) = 1 */
//	assert( d_sin( +1.e-16 ) 	== 1.0 		); /* sin( +o ) = 1 */
//	assert( d_sin( -1.e-16 ) 	== 1.0 		); /* sin( -o ) = 1 */
}

int main( void )
{
	double twobypi = 0.6366197723675813430755350;
	double pi = 3.1415926535897932384;
	double x = twobypi + 0.0001;

	double g 	= x * twobypi; // g = x / 0.5pi
	long quad 	= (long)(0 < g ? g + 0.5 : g - 0.5); //

	printf("x = %f, g = %f, quad = %ld\n",x, g, quad );
	
	printf("SIN\n");

//	d_sin(1.6);
	double min_sin_err = 1000.0;
	double max_sin_err = 0.0;

	double min_cos_err = 1000.0;
	double max_cos_err = 0.0;

	for(double x = -6.3 ; x < 6.3; x+=0.2)
	{
		const double err_sin = sin(x) - d_sin(x);
		const double abs_err_sin = err_sin < 0. ? -err_sin : err_sin;
		max_sin_err = max_sin_err < abs_err_sin ? abs_err_sin : max_sin_err;
		min_sin_err = abs_err_sin < min_sin_err ? abs_err_sin : min_sin_err;

		const double err_cos = cos(x) - d_cos(x);
		const double abs_err_cos = err_cos < 0. ? -err_cos : err_cos;
		max_cos_err = max_cos_err < abs_err_cos ? abs_err_cos : max_cos_err;
		min_cos_err = abs_err_cos < min_cos_err ? abs_err_cos : min_cos_err;

		printf("%.12f, %.12f, %.12f\n",x, d_sin(x), d_cos(x));
	}


	printf("ABS ERROR: MAX = %e, MIN = %e\n", max_sin_err, min_sin_err);
	printf("ABS ERROR: MAX = %e, MIN = %e\n", max_cos_err, min_cos_err);

	return 0;
#if 0
	printf("Testing _test(x)\n");

	printf("TODO: review gradual underflow: sqrt(%.12e) = %.12e\n", 1.e-320, d_sqrt(1.e-320));

	test_sqrt();
	test_exp();
	test_log();
	test_sin();

	double x;
	dnorm_t xn;

	x = -1.e-309; xn = d_normalize(x); printf("%.12e = %.12e x 2 ^ %d = %.12e\n", x, xn.f.d, xn.e, xn.f.d*pow(2.0, xn.e));
	
	x = 0.0; 			assert( ZERO 	== d_type(x));
	x = 1./0.; 			assert( INF 	== d_type(x));
	x = -1./0.; 		assert( INF 	== d_type(x));
	x = -1./-0.; 		assert( INF 	== d_type(x));
	x = 1./0. + 1./0.; 	assert( INF 	== d_type(x));
	x = 1.e-320; 		assert( GRADZ 	== d_type(x));
	x = 1./0. - 1./0.; 	assert( NAN 	== d_type(x));
	x = 0.0*(1./0.); 	assert( NAN 	== d_type(x));
	x = 1.0; 			assert( FINITE 	== d_type(x));
	x = -1.E12; 		assert( FINITE 	== d_type(x));
	x = 1. - 1.; 		assert( ZERO 	== d_type(x));

	x = +120.0; xn = d_normalize(x); assert( xn.f.d == +0.9375 && xn.e == 7 && xn.type == FINITE ); //printf("frac = %.12f, exp = %d\n", xn.f, xn.e);
	x = -120.0; xn = d_normalize(x); assert( xn.f.d == -0.9375 && xn.e == 7 && xn.type == FINITE );
	x = -0.01 ; xn = d_normalize(x); assert( xn.f.d == -0.64   && xn.e == -6 && xn.type == FINITE );
	x = 0.5e-10 ; xn = d_normalize(x); assert( xn.f.d == 0.8589934592 && xn.e == -34 && xn.type == FINITE );
	x = 1./0. ; xn = d_normalize(x); assert( xn.f.d == 1./0.   && xn.e == 0 && xn.type == INF );

	x = 4.9E-324;
	xn = d_normalize(x);

	return 0;
#endif
}
