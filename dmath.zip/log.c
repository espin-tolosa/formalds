#include "dmath.h"

static double d_log_imp( double x );

extern double d_log( double x )
{
	return d_log_imp( x );
}

static double d_log_imp( double x )
{
	const double ln2 = 0.69314718055994530941723212145818;

	dnorm_t xn = d_normalize( x );
	dnorm_t gn = d_normalize( xn.f.d );

	dnorm_t result = { 0 };

	result.type 		= d_type( x );
	result.f.w[ W0 ] 	= result.type;
	
	double f = gn.f.d;

	double z = 2.0 * ( f - 1.0 ) / ( f + 1.0 );

	double yn = z;

	z = z * z * z;
	yn = yn + z / 12.0;
	
	z = z * z * z;
	yn = yn + z / 80.0;

	z = z * z * z;
	yn = yn + z / 448.0;
	
	z = z * z * z;
	yn = yn + z / 2304.0;
	
	z = z * z * z;
	yn = yn + z / 11264.0;

	z = z * z * z;
	yn = yn + z / 49811.282184751;

	return ( ( xn.e - gn.e ) * ln2 + yn );
}
