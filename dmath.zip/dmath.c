#include "dmath.h"

u16_t d_type ( double x )
{
	u16_t result;

	const dw_t 		px 					= { .d = x };
	const i16_t 	exponent			= ( px.w[ W0 ] & DMASK ) >> DOFF;
	const bool_t 	mantisa_not_zero	= ( px.w[ W0 ] & DFRAC ) || px.w[ W1 ] || px.w[ W2 ] || px.w[ W3 ];

	if ( exponent == DMAX )
	{
		if ( mantisa_not_zero )
		{
			result = NAN;			/* exponent == DMAX	, mantissa != 0 */
		}
		else
		{
			result = INF;			/* exponent == DMAX	, mantissa == 0 */
		}
	}
	
	else
	{
		if ( exponent != 0 )
		{
			result = FINITE;		/* exponent != 0	, mantissa N/A,  */
		}
		
		else if ( mantisa_not_zero )
		{
			result = GRADZ;			/* exponent == 0	, mantissa != 0 */
		}

		else
		{
			result = ZERO;			/* exponent == 0	, mantissa == 0 */
		}
	}

	return (result);
}

/*
 * NORMALIZE
 * x = f * 2^e with 0.5 <= |f| < 1
 */
 
dnorm_t d_normalize ( double x )
{
	dnorm_t result = { 0 };

	result.type 		= d_type( x );
	result.f.w[ W0 ] 	= result.type;

	if( result.type == FINITE )
	{
		const dw_t px = { .d = x };

		result.e = ( ( px.w[ W0 ] & DMASK ) >> DOFF ) - DBIAS;

		result.f.w[ W0 ] = (px.w[ W0 ] & SMMASK) | ONEHALF ;
		result.f.w[ W1 ] = px.w[ W1 ];
		result.f.w[ W2 ] = px.w[ W2 ];
		result.f.w[ W3 ] = px.w[ W3 ];
	}

	else if ( result.type == GRADZ )
	{
		const dw_t px = { .d = x };

		result.f.w[ W0 ] = (px.w[ W0 ] & MMASK);
		result.f.w[ W1 ] = px.w[ W1 ];
		result.f.w[ W2 ] = px.w[ W2 ];
		result.f.w[ W3 ] = px.w[ W3 ];

		u64_t mantissa = result.f.u;

		result.e = -DBIAS;
	
		i32_t found = 0;

		for( i32_t i = 51; i >= 0 && !found; i = -1 + i )
		{
			found 		= (mantissa & (1ULL << i)) != 0;

			result.e 	= result.e - 1;
			mantissa 	= mantissa << 1;
		}

		result.e 			= result.e - 1;
		result.f.u 			= ( mantissa & 0xFFFFFFFFFFFFF ) | ((u64_t)(px.w[ W0 ] & SMASK) | ONEHALF) << 48;
	}
	
	return (result);
}

/*
 * GRADUAL UNDERFLOW NORMALIZE
 * x = f * 2^e with 0.5 <= |f| < 1
 */

dnorm_t d_gnormalize ( double x )
{
	return ( (dnorm_t) { 0 } );
}
