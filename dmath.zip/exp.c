#include "dmath.h"

static double d_exp_imp( double x );

extern double d_exp( double x )
{
	dnorm_t xn = d_normalize( x );
	
	dnorm_t result = { 0 };

	result.type 		= d_type( x );
	result.f.w[ W0 ] 	= result.type;

	switch( result.type )
	{
		case (FINITE):
		{
			result.f.d =  d_exp_imp( x );
			break;
		}

		case (INF):
		{
			if( x < 0 ) result.f.w[ W0 ] = ZERO;
			break;
		}

		case (ZERO):
		{
			result.f.d =  1.0;
			break;
		}

		case (GRADZ):
		{
			result.f.d =  1.0;
			break;
		}


		default: /* NOP */
	}

	return result.f.d;
}

/*
 * x = g + e * ln2; exp(x) = 2**e * exp(g)
 */

double d_exp_imp( double x )
{	
	int neg;
	
	if( x < 0.0 )
	{
		x = -x;
		neg = 1;
	}
	else
	{
		neg = 0;
	}

	/* Cody & Waite, Chapter 6, page 69 */
	const double p0 	= 0.25000000000000000000e+0;
	const double p1 	= 0.75753180159422776666e-2;
	const double p2 	= 0.31555192765684646356e-4;
	const double q0 	= 0.50000000000000000000e+0;
	const double q1 	= 0.56817302698551221787e-1;
	const double q2 	= 0.63121894374398503557e-3;
	const double q3 	= 0.75104028399870046114e-6;
	const double invln2 = 1.442695040888963407;
	const double c1 	= 22713.0 / 32768.0;
	const double c2 	= 1.428606820309417232e-6;

	/* x = g + e * ln2 */
	const int  		e = (int)(x * invln2 + 0.5);
	const double 	g = (x - (double)e * c1) - (double)e * c2; /* Cody & Waite, Chapter 6, page 68, machines with guard digit */

	const double z = g * g;
	
	const double gP = g * ( (p2 * z + p1) * z + p0 );
	const double Q  = (q3 * z + q2) * z + q1;
	const double R 	= 0.5 + gP / (Q * z + q0 - gP);

	double k2 = 1.0;
	
	for( int i = 0; i < (1 + e); ++i ) { k2 = 2.0 * k2;	}

	if( neg )
	{
		return 1.0 / ( R * k2 );
	}
	else
	{
		return R * k2;
	}
}
