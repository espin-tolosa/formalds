# Notes on Elementary Functions by Jean-Michel Muller

# Chapter 2 - Introduction to Computer Arithmetic

Page	Note

3.		The desired scenario of the underlying arithmetic is to have a "significantly higher precission".
		For example, using FP64 arithmetic to implement FP32 library.

3.		We only can compute polynomials by using the arithmetic operators: ```+, -, *, /```

4.		One strategy is a combination of look-up table for the closest value f0, plus correction by polynomial interpolation, e.g.
		```f(x) = f0(x) = correction(x, x0)``` 

4.		The operation of "range reduction" of ```x``` gives the "reduced argument" ```x*```.

4.		"Range reduction" example: 		```x = 88.34```, 		```x* = x - kπ/2```, 		```|x| < π/4```, gives:
		```k = 56```, ```x* = x - 56π/2 = 0.375...```

4.		Algorithms cathegories for elementary functions:

		- polynomial approximations
		- table-based methods
		- shift-and-add algorithms

4.		Range reduction is the most critical part of the algorithm

5.		Precission ```p ≥ 2``` is the number of "significant digits" of the representation, where the representation is: ```±m × β**e```

5.		```x = M · β**(e − p + 1)```

6.		ULP: "unit in the last place", is the magnitude of the last significant digit: ```ulp(x) = β**( ex - p + 1 )```

17.		The 2SUM algorithm, allows to compute the sum of ```a + b``` and also to know the commited error (given by ```t```).

## Chapter 3 - Polynomial Theory

39. 	The error of approximate a function by a piecewise polynomial is composed by two factors:

		- approximation error: it is the error of the model
		- evaluation    error: it is the error of the arithmetics

40. 	Polynomial Taylor approximation is not a good solution in general, because evaluation is really slow

## Chapter 5 - Polynomial Evaluation

81.		Horner's Scheme, it is a fast evaluation of ```P(x)``` for non-parallel computation

		```
		P(x) = an·x**n + an_1·x**n_1 + an_2·x**n_2 + ... + a0
		
		horner_rule : y

		1. y <- an·x + an_1
		2. for i in [n-2, 0]
			y <- y·x + ai		
		```
		
# Chapter 11 - Range Reduction

199.	Every elementary function good algorithm is composed by the steps:

		1. Argument reduction: additive or multiplicative
		
			- additive reduction		: ```x* = x - kC```

			- multiplicative reduction	: ```x* = x/C**k```

		2. Branching ```x*``` to the domains of convergence
	
		3. Argument reconstruction

199.	Argument reduction ranges:

			- additive reduction		: ```|x*| ≤ C/2```

			- multiplicative reduction	: ```1/C ≤ |x*| < 1``` (TBD: review the generality of this range)


202.	Poor argument reduction can lead to catastrophic results, e.g. sin(x) naive argument reduction:

		- ```k = ⌊x/C⌋```
		
		- ```x* = RN(x - RN(kC))```

		If ```kC``` is close to ```x``` all the precission of performing ```x - RN(kC)``` is gone.
		For example, if ```C = π/2```, it will happen when ```x``` is a large multiple of ```π/2```






























