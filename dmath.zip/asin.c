#include "dmath.h"

extern double d_asin    ( double x )
{
    return ( 0.0 );
}